package com.example.tugasbesaruas.API

import retrofit2.Call
import retrofit2.http.GET

interface JokeApiService {
    @GET("Any?blacklistFlags=nsfw,religious,racist,sexist,explicit&idRange=0-100")
    fun getJoke(): Call<JokeResponse>
}