package com.example.tugasbesaruas

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import com.example.tugasbesaruas.API.JokeApiService
import com.example.tugasbesaruas.API.JokeResponse
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.*
import retrofit2.converter.gson.GsonConverterFactory

class MainActivity : AppCompatActivity() {

    private lateinit var tvJoke: TextView
    private lateinit var btnGetJoke: Button
    private lateinit var jokeApiService: JokeApiService

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        tvJoke = findViewById(R.id.tvJoke)
        btnGetJoke = findViewById(R.id.btnGetJoke)

        // Initialize Retrofit
        val logging = HttpLoggingInterceptor()
        logging.level = HttpLoggingInterceptor.Level.BODY
        val httpClient = OkHttpClient.Builder()
        httpClient.addInterceptor(logging)

        val retrofit = Retrofit.Builder()
            .baseUrl("https://v2.jokeapi.dev/joke/")
            .addConverterFactory(GsonConverterFactory.create())
            .client(httpClient.build())
            .build()

        jokeApiService = retrofit.create(JokeApiService::class.java)

        btnGetJoke.setOnClickListener {
            fetchJoke()
        }
    }

    private fun fetchJoke() {
        jokeApiService.getJoke().enqueue(object : Callback<JokeResponse> {
            override fun onResponse(call: Call<JokeResponse>, response: Response<JokeResponse>) {
                if (response.isSuccessful) {
                    val jokeResponse = response.body()
                    jokeResponse?.let {
                        if (it.type == "single") {
                            tvJoke.text = it.joke
                        } else {
                            tvJoke.text = "${it.setup}\n${it.delivery}"
                        }
                    }
                } else {
                    Toast.makeText(this@MainActivity, "Failed to get joke", Toast.LENGTH_SHORT).show()
                }
            }

            override fun onFailure(call: Call<JokeResponse>, t: Throwable) {
                Toast.makeText(this@MainActivity, "Error: ${t.message}", Toast.LENGTH_SHORT).show()
            }
        })
    }
}